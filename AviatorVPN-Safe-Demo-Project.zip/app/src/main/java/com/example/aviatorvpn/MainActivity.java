package com.example.aviatorvpn;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST = 1001;
    private TextView status;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 70, 40, 40);

        TextView title = new TextView(this);
        title.setText("Aviator VPN Demo");
        title.setTextSize(28);

        status = new TextView(this);
        status.setText("Status: Disconnected");
        status.setTextSize(18);
        status.setPadding(0, 25, 0, 25);

        Button connect = new Button(this);
        connect.setText("CONNECT");
        connect.setOnClickListener(v -> requestVpn());

        Button disconnect = new Button(this);
        disconnect.setText("DISCONNECT");
        disconnect.setOnClickListener(v -> {
            stopService(new Intent(this, AviatorVpnService.class));
            status.setText("Status: Disconnected");
        });

        root.addView(title);
        root.addView(status);
        root.addView(connect);
        root.addView(disconnect);
        setContentView(root);
    }

    private void requestVpn() {
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            startActivityForResult(intent, VPN_REQUEST);
        } else {
            startVpn();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST && resultCode == RESULT_OK) {
            startVpn();
        } else if (requestCode == VPN_REQUEST) {
            status.setText("Status: Permission denied");
        }
    }

    private void startVpn() {
        startService(new Intent(this, AviatorVpnService.class));
        status.setText("Status: VPN interface started");
    }
}
