package com.example.aviatorvpn;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

public class AviatorVpnService extends VpnService {
    private ParcelFileDescriptor vpnInterface;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (vpnInterface == null) {
            vpnInterface = new Builder()
                .setSession("Aviator VPN Demo")
                .setMtu(1500)
                .addAddress("10.8.0.2", 32)
                .addRoute("10.8.0.0", 24)
                .establish();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (vpnInterface != null) {
            try { vpnInterface.close(); } catch (Exception ignored) {}
            vpnInterface = null;
        }
        super.onDestroy();
    }
}
