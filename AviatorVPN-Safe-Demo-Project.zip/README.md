# Aviator VPN Demo

A learning/demo Android VPN project.

It contains a real Android VpnService declaration, so the Android system can display
the VPN permission dialog.

IMPORTANT:
This demo creates a local VPN/TUN interface only. It does not provide a remote VPN
server, packet forwarding, traffic interception, or access to gambling/betting services.

To build:
- Open the project in a compatible Android IDE with Android SDK 35 and JDK 17.
- Run the Gradle task `assembleDebug`.
- Install `app/build/outputs/apk/debug/app-debug.apk`.

For Android 11+, pressing CONNECT should invoke Android's VPN permission flow.
